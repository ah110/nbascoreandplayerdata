// import { Link } from 'react-router-dom';
// //import { useHistory } from 'react-router-dom';
// import { useHistory } from 'react-router';


// <Link to="/livescores">
//   <button>View Live Scores</button>
// </Link>

// // function Main() {
// //     return (
// //         <div>
// //             <h1>Welcome to NBA live score</h1>
// //             <Link to="/livescores">
// //               <button>View Live Scores</button>
// //             </Link>
// //         </div>
// //     )
// // }


// function Main() {
//   const history = useHistory();

//   const handleClick = () => {
//     history.push('/livescores');
//   };

//   return (
//     <div>
//       <h1>Welcome to NBA Live Scores</h1>
//       <button onClick={handleClick}>View Live Scores</button>
//     </div>
//   );
// }



// // const Main = () => {
// //     const history = useHistory();
// //     const redirectToLiveScores = () => {
// //         history.push('/livescores')
// //     }
    

// //     return (
// //         <div>
// //             <h1>Welcome to NBA live score</h1>
// //             <Link to="/livescores">
// //               <button>View Live Scores</button>
// //             </Link>
// //         </div>
// //     )





// export default Main;
