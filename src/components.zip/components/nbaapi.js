// export const fetchLiveScores = () => {
    
//     return fetch('https://free-nba.p.rapidapi.com/games?page=0&per_page=25&Seasons=2022')
//         .then(response => response.json())
//         .then(data => {
//             // Do something with the data
//             return data;
//         })
//         .catch(error => {
//             console.log(error);
//         });
// };
